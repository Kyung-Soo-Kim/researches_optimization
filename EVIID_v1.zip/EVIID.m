%% EVIID Main algorithm (2019)
% Developer: Kyung Soo Kim (kyungskim@hanyang.ac.kr, Hanyang University)

% EVIID.m: This code is a main algorithm of EVIID

function [seps, nonseps, FEs, epsilon, exctimes] = EVIID(funID, params)
%% Initialization
    st = tic;
    
    fun_name = params.fun;
    dim = params.dim;
    lbval = params.lb;
    ubval = params.ub;
    NP = params.NP;
    alpha = params.alpha;
    cz = params.cz;
    
    lb = ones(1,dim)*lbval;      % Lower-bound for each dimension
    ub = ones(1,dim)*ubval;      % Upper-bound for each dimension
    
    DCT = sparse(dim,dim);       % Dynamic perturbation caching table (n by n sparse matrix)
    VIF = zeros(1,dim);          % Variable influence factors (n-dimensional array)
    seps = []; nonseps = {};
    
%% Estimate the threshold value (epsilon) adaptively based on the magnitude of the objective funtion. 
    x = (ubval-lbval).*rand(NP,dim)+lbval;
    epsilon = alpha*min( abs( feval(fun_name, x, funID) ) );
    
%% The dynamic perturbation caching and the pre-variable sorting are performed. 
    x1 = lb;
    y1 = feval(fun_name, x1, funID);
    FEs = NP + 1;

    for var = 1:1:dim
        x2 = x1;
        x2(var) = (lb(var)+ub(var))./2;
        
        fitVal = feval(fun_name, x2, funID);
        FEs = FEs + 1;
        if fitVal ~= 0
            DCT(var, var) = fitVal;
        else  % fitVal == 0
            DCT(var, var) = cz;
        end
        
        VIF(var) = abs( fitVal - y1 );
    end
    
    [~, varListIndex] = sort(VIF, 'descend');
    
    Starget = varListIndex(1);        % Target variable or variable group
    Svst = varListIndex(2:1:end);     % Remain variables

%% The variables in the VST are decomposed into the variable groups according to their interdependencies. 
    while ~isempty(Svst)
       x2 = x1;
       x2(Starget) = (lb(Starget)+ub(Starget))./2;
       
       if length(Starget) == 1      % Starget contains only one variable.
          y2 = DCT(Starget, Starget);
          if y2 == cz
              y2 = 0;
          end
       elseif length(Starget) == 2  % Starget contains two variables.
          v1 = min(Starget);
          v2 = max(Starget);
          
          if DCT(v1, v2) ~= 0  % There exists the cached fitness in the DCT.
             y2 = DCT(v1, v2);
             if y2 == cz
                 y2 = 0;
             end
          else
             y2 = feval(fun_name, x2, funID);
             FEs = FEs + 1;
             if y2 ~= 0
                 DCT(v1, v2) = y2;
             else  % y2 == 0
                 DCT(v1, v2) = cz;
             end
          end
       else
          % For efficiency of the algorithm, three or more variables are not indexed.
          y2 = feval(fun_name, x2, funID);
          FEs = FEs + 1;
       end
       
       delta1 = y2 - y1;
       [Sinteract, DCT, FEs] = searchInteract(Starget, Svst, x1, delta1, lb, ub, epsilon, DCT, FEs, params);
       
       %% The returned interdependent variables are classified into the separable or nonseparable variables.
       if isempty(Sinteract) % No interactions
          if length(Starget) == 1 
             seps = [seps; Starget];
          else
             nonseps = {nonseps{1:end}, Starget};
          end
          
          Starget = []; Sinteract = [];
          
          Starget = Svst(1);    % Select a next target variable.
          Svst = Svst(2:1:end);
       else                     % There are some variable interactions.
          Starget = union(Starget, Sinteract);
          Svst = setdiff(Svst, Starget, 'stable');
          Sinteract = [];
       end
       
       %% If there are not remaining variables in the VST, they are classified as separable or nonseparable variables.
       if isempty(Svst)  
          if length(Starget) == 1
              seps = [seps; Starget];
          else
              nonseps = {nonseps{1:end}, Starget};
          end
          break;
       end
    end
    
    exctimes = toc(st);
end % end of function