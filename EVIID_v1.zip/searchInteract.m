%% EVIID searchInteract algorithm (2019)
% Developer: Kyung Soo Kim (kyungskim@hanyang.ac.kr, Hanyang University)

% searchInteract.m: This algorithm extracts all variables interdependent with
% Starget from Svst. This algorithm is called in EVIID.m.

function [Sinteract, DCT, FEs] = searchInteract(Starget, Svst, x1, delta1, lb, ub, epsilon, DCT, FEs, params)
    %% Initialization
    fun_name = params.fun;
    funID = params.funid;
    cz = params.cz;
    
    Sinteract = [];
    listIndex.low = 1;
    listIndex.high = length(Svst);
    
    Queue = [listIndex]; % Queue for Breadth-First Search 
    
    %% All the variables interdependent with Starget are extracted from the VST in the BFS manner.
    while true
        % Queue.Delete() operation
        leftIndex = Queue(1).low;   
        rightIndex = Queue(1).high;
        Queue(1) = [];
        
        St = Svst(leftIndex : rightIndex);
        
        x3 = x1;
        x3(St) = (lb(St)+ub(St))./2;
        
        if length(St) == 1 
           y3 = DCT(St, St);
           if y3 == cz
               y3 = 0;
           end
        elseif length(St) == 2
           v1 = min(St);
           v2 = max(St);
           
           if DCT(v1, v2) ~= 0
              y3 = DCT(v1, v2);
              if y3 == cz
                  y3 = 0;
              end
           else
              y3 = feval(fun_name, x3, funID);
              FEs = FEs + 1;
              if y3 ~= 0
                  DCT(v1, v2) = y3;
              else  % y3 == 0
                  DCT(v1, v2) = cz;
              end
           end
        else % For efficiency of algorithm, three or more variables are not indexed.
           y3 = feval(fun_name, x3, funID);
           FEs = FEs + 1;
        end      
        
        x4 = x3;
        x4(Starget) = (lb(Starget)+ub(Starget))./2;
        
        if length(Starget) == 1 && length(St) == 1 % For indexing two variable (a leaf tree having two child variables)
           v1 = min(Starget, St);
           v2 = max(Starget, St);
           
           if DCT(v1, v2) ~= 0
              y4 = DCT(v1, v2);
              if y4 == cz
                  y4 = 0;
              end
           else
              y4 = feval(fun_name, x4, funID);
              FEs = FEs + 1;
              if y4 ~= 0
                  DCT(v1, v2) = y4;
              else  % y4 == 0
                  DCT(v1, v2) = cz;
              end
           end
        else % For efficiency of algorithm, three or more variables are not indexed.
           y4 = feval(fun_name, x4, funID);
           FEs = FEs + 1;
        end
        
        delta2 = y4 - y3;
        delta = abs( delta1 - delta2 );  % The interdependency is computed.
        
        % Pruning: If this node has interaction, search its child nodes
        if delta > epsilon
           if length(St) == 1   % Leaf node ==> One variable
              Sinteract = union(Sinteract, St);
           else   % Non leaf node ==> To search its childrens, add its child nodes into the queue
              [Lindex, Rindex] = divideListIndex(leftIndex, rightIndex);
              Queue = [Queue, Lindex, Rindex];   % Queue.add(IndexLeft); Queue.add(IndexRight);
           end
        end
        
        % If the queue is empty, the search process is terminated.
        if isempty(Queue)
           break; 
        end
    end
end

%% EVIID divideListIndex algorithm
% Developer: Kyung Soo Kim (kyungskim@hanyang.ac.kr)

function [ Lindex, Rindex ] = divideListIndex( leftIndex, rightIndex )
        n = rightIndex - leftIndex + 1;
        mid = floor(n/2);
        Lindex.low = leftIndex; 
        Lindex.high = leftIndex + mid - 1;
        Rindex.low = leftIndex + mid;
        Rindex.high = rightIndex;
end