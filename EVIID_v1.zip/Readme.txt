EVIID (2019): These files are EVIID's Matlab implementation source codes.

< Files>
  - runTest.m : Running source code. (To run EVIID, this code is used.) 
  - EVIID.m : Main algorithm of EVIID.
  - searchInteract.m : This is used in EVIID.m. 
  - analysis_accuracy : To analyze the decomposition accuracy of EVIID, this code is used.
 
< Folders >
 - CEC_Benchmarks : The CEC'2010 benchmark functions and their datafiles are contained.
 - results : The decomposition results of EVIID are contained.


* Contact: Kyung Soo Kim (kyungskim@hanyang.ac.kr, kyungskim1732@gmail.com)