% Developer: Kyung Soo Kim (kyungskim@hanyang.ac.kr, Hanyang University)

% This algorithm estimates decomposition accuracy of EVIID by reading the 
% decomposition results and analyzing them.

% Note: This code has been modified by Kyung Soo Kim from the original code 
% made by Mohammad Nabi Omidvar [1] and the modified code by Yuan Sun [2].
% The referenced papers are as follows.
% [1] M.N. Omidvar, X. Li, Y. Mei, X. Yao, Cooperative Co-Evolution With Differential Grouping for Large Scale Optimization, IEEE Transactions on Evolutionary Computation, 18 (2014) 378-393.
% [2] Y. Sun, M. Kirley, S.K. Halgamuge, A Recursive Decomposition Method for Large Scale Continuous Optimization, IEEE Transactions on Evolutionary Computation, 22 (2018) 647-661.

% Main function
function analysis_accuracy()
    clear all; clc;
    
    runBasicAccuracy();
end

function runBasicAccuracy()
    D = 1000;
    funcs = 1:1:20;
    more off;
    
    m = 50; % The number of variables in a group
    numNonSepGroups = [0 0 0 1 1 1 1 1 10 10 10 10 10 20 20 20 20 20 1 1];
    numSepVars = [1000 1000 1000 950 950 950 950 950 500 500 500 500 500 0 0 0 0 0 0 0];
    numNonSepVars = [0 0 0 50 50 50 50 50 500 500 500 500 500 1000 1000 1000 1000 1000 1000 1000];
    
    printTable(1:20, 1:3) = -1; % A table to print all statistics on the disk
    outfilename = './results/EVIID_DP_TestResult_Accuracy.mat'; % Output file name
    
    for funid = funcs
        filename = sprintf('./results/EVIID_DP_F%02d.mat', funid); % Result file name
        
        FEs = 0;
        leng = 20;
        p = 1:1:D;
        
        load(filename);
        
        mat = zeros(length(nonseps), leng);
        drawline('=');
        fprintf('Function F: %02d\n', funid);
        fprintf('FEs used: %d\n', FEs);
        fprintf('epsilon used: %d\n', eps);
        fprintf('Number of separables variables: %d\n', length (seps));
        fprintf('Number of non-separables groups: %d\n', length (nonseps));
        
        filename1 = sprintf('./CEC_Benchmarks/cec2010/datafiles/f%02d_op.mat', funid);
        filename2 = sprintf('./CEC_Benchmarks/cec2010/datafiles/f%02d_opm.mat', funid);
        flag = false;
        if(exist(filename1))
            load(filename1);
            flag = true;
        elseif(exist(filename2))
            load(filename2);
            flag = true;
        end
    
        printheader();
        
        idealSeps = [];
        for i=1:1:length(nonseps)
            fprintf('Size of G%02d: %3d  |  ', i, length (nonseps{i}));
            if(flag)
                for g=1:1:leng
                    if g > numNonSepGroups(funid) 
                        idealSeps = union(idealSeps, p((g-1)*m+1:g*m));
                    end
                    
                    captured = length(intersect(p((g-1)*m+1:g*m), nonseps{i}));
                    fprintf(' %4d', captured);
                    mat(i, g) = captured;
                end
            end
            fprintf('\n');
        end
        
        if funid >=1 && funid <=3     % All the variables are separable.
            idealSeps = 1:1:D;
        elseif funid >= 14 && funid <= 20 % No separable variables.
            idealSeps = [];
        end
        
        mat2 = mat;
        [temp I] = max(mat, [], 1);
        [sorted II] = sort(temp, 'descend');
        masks = zeros(size(mat));
        for k = 1:min(size(mat))
            mask = zeros(1, length(sorted));
            mask(II(k)) = 1;
            masks(I(II(k)), :) = mask;
            %point = [I(k) II(k)];
            mat(I(II(k)), :) = mat(I(II(k)), :) .* mask;
            [temp I] = max(mat, [], 1);
            [sorted II] = sort(temp, 'descend');
        end
        mat = mat2 .* masks;
        [temp I] = max(mat, [], 1);
        
        if(ismember(funid, [19 20]))
            gsizes = cellfun('length', nonseps);
            fprintf('Number of non-separable variables correctly grouped: %d\n', max(gsizes));
            correctClassifiedNonSeps = max(gsizes);
        else
            fprintf('Number of non-separable variables correctly grouped: %d\n', sum(temp(1:numNonSepGroups(funid))));
            correctClassifiedNonSeps = sum(temp(1:numNonSepGroups(funid)));
        end
        
        nonsepVarGroupAccuracy = correctClassifiedNonSeps/numNonSepVars(funid);
        
        intersectSeps = intersect(seps, idealSeps);
        numOfCorrectedSeps = length(intersectSeps);
        lenIdSeps = length(idealSeps);
        if lenIdSeps == 0 
            sepVarIdenAccuracy = NaN;
        else
            sepVarIdenAccuracy = numOfCorrectedSeps / lenIdSeps;
        end
                
        drawline('=');
        
        % Save the statistics into the printTable array to save them on the disk.
        printTable(funid,1) = funid;
        printTable(funid,2) = sepVarIdenAccuracy;
        printTable(funid,3) = nonsepVarGroupAccuracy;
        
        fprintf('  - Sep Var Identification Accuracy: %d\n', sepVarIdenAccuracy);
        fprintf('  - NonSep Grouping Accuracy: %d\n', nonsepVarGroupAccuracy);
        
        pause;
    end
    
    % For saving the result frile, this code is used.
%     save (outfilename, 'printTable', '-v7'); 
end


% Helper Functions ----------------------------------------------------------
function drawline(c)
    for i=1:121
        fprintf(1,c);
    end
    fprintf('\n')
end

function printheader()
    fprintf('Permutation Groups|  ');
    for i=1:20
        fprintf(' %4s', sprintf('P%d', i));
    end 
    fprintf('\n')
    drawline('-');
end
% End Helper Functions ------------------------------------------------------