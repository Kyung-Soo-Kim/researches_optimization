%% EVIID Running Algorithm (2019)
% Developer: Kyung Soo Kim (kyungskim@hanyang.ac.kr, Hanyang University)

% runTest.m: Test EVIID on the CEC 2010 benchmark functions
clear all;
clc;

funIDList = 1:1:20;
statTable(1:20,1:4) = 0;

%% For each benchmark function, run experiment (funID = test function's ID)
for funID = funIDList
    %% For each of functions, set possible variable scopes
    if (funID == 1 | funID == 4 | funID == 7 | funID == 8 | funID == 9 | funID == 12 | ... 
            funID == 13 | funID == 14 | funID == 17 | funID == 18 | funID == 19 | funID == 20) % -100 <= x <= 100
        lb = -100;
        ub = 100;
    elseif (funID == 2 | funID == 5 | funID == 10 | funID == 15) % -5 <= x <= 5
        lb = -5;
        ub = 5;
    elseif (funID == 3 | funID == 6 | funID == 11 | funID == 16)  % -32 <= x <= 32
        lb = -32;
        ub = 32;
    else
        disp('Error: Inaccurate benchmark function ID. The range of the benchmark function is 1 - 20');
        break;
    end
    
    %% Set parameters for the experiment
    params.fun = 'benchmark_func';
    params.dim = 1000;       % Dimensions
    params.funid = funID;    % Benchmark function's ID
    params.lb = lb;          % Upper bound
    params.ub = ub;          % Lower bound
    params.cz = Inf;         % A constant to cache a zero fitness into a DCT implemented by the sparse matirx.
    params.NP = 10;          % The number of samples to estimate the parameter epsilon
    params.alpha = 10^-11;   % Basic Parameter = 10^-11
    
    % Set directory path containing the benchmark functions
    addpath('CEC_Benchmarks/CEC2010');
    addpath('CEC_Benchmarks/CEC2010/datafiles');
    
    global initial_flag;     % The global flag used in test suite
    initial_flag = 0;        % Set the flag to 0 for each run, each function
    
    %% Run EVIID algorithm
    [seps, nonseps, FEs, epsilon, exctimes] = EVIID(params.funid, params);
    
    %% Print the experimental results
    statTable(funID,1) = funID; statTable(funID,2) = length(seps); statTable(funID,3) = length(nonseps); statTable(funID,4) = FEs;
    outResultFilePath = sprintf('./results/EVIID_DP_F%02d', params.funid);
    
    if funID ~=20
        save (outResultFilePath, 'seps', 'nonseps', 'FEs', 'epsilon', '-v7');
    else
        save (outResultFilePath, 'seps', 'nonseps', 'FEs', 'epsilon', 'statTable', '-v7');
    end
    
    fprintf('[Fun %d]\t %d\t %f \n', funID, FEs, exctimes);
end